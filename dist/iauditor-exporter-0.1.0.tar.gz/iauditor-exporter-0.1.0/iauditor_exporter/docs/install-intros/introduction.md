# Installation

## Overview

If you're comfortable using Git and running commands from the command prompt, these instructions should give you what you need:

#### [Quick install instructions](../../install-intros/quick-install/)

## Detailed Guidance

If you're new to running scripts, [follow the detailed guidance](../../install-intros/detailed-install/).