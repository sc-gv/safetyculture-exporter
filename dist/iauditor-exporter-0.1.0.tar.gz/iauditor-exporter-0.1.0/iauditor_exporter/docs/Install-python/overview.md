# 1. Install Python

The iAuditor Exporter is coded in a language called Python so we need to install Python so that your computer can understand the code. 

Python is available in many different versions, ranging from version 2.7 all the way through to 3.8 at the time of writing. For our script, you'll need at least Python 3.6. Installation varies depending on the operating system you're using:

#### If you're on Windows, start [here](../../Install-python/windows/)
#### If you're on macOS, start [here](../../Install-python/mac/)