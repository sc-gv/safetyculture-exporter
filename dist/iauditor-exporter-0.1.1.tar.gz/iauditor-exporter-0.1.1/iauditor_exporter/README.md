# iAuditor Exporter Tool

## Intoduction
The iAuditor Exporter tool is the primary way to bulk export iAuditor information for use in BI tools such as PowerBI. The tool is coded in the Python programming language and can be ran simply and easily on any computer with Python installed.

![Power BI Example](https://safetyculture.github.io/iauditor-exporter/images/powerbi.png)

## [Documentation](https://safetyculture.github.io/iauditor-exporter/)

Extensive documentation is available [here](https://safetyculture.github.io/iauditor-exporter/).