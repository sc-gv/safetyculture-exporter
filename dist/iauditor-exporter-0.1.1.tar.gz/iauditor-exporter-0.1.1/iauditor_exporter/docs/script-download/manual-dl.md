# Manually Downloading the Script

If you're unable to use Git, you can manually download the script. 

1. Go to this link: [https://github.com/SafetyCulture/iauditor-exporter/archive/master.zip](https://github.com/SafetyCulture/iauditor-exporter/archive/master.zip)
2. Copy the downloaded zip file into a folder you can access. Your Documents folder tends to be a good choice. 
3. Extract the folder - in Windows just right click and select 'Extract All'. On macOS, just double click it. 
4. Open up the extracted folder, we'll cover setting up the script in the next section. 